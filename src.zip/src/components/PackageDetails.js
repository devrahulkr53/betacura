import React, { Component } from 'react'
import { useForm } from "react-hook-form";

export default function PackageDetails(props){
  const { values, setValues, handleStep, family, setFamily } = props
  const { register, getValues, handleSubmit, watch, errors } = useForm();
  
  const [totalPrice1,setPrice1] = React.useState(0);
  const [totalPrice2,setPrice2] = React.useState(0);
  const [totalPrice,setPrice] = React.useState(0);
 
  const addons = [
    {value:"Vitamin B12",price:323},
    {value:"CBC",price:523},
    {value:"Iron Profile",price:123},
    {value:"Vitamin B12",price:323},
  ]
  
  const handleChange1 = () => {
    const data = getValues("addons1")
    var price = 0;
    data.map(el=>{
      price += addons[Number(el)].price
    })
    setPrice1(price)
  }
  const handleChange2 = () => {
    const data = getValues("addons2")
    var price = 0;
    data.map(el=>{
      price += addons[Number(el)].price
    })
    setPrice2(price)
  } 

  const onSubmit = (data) => {
    var addons1 = data.addons1?.map(e=>addons[Number(e)].value)
    var addons2 = data.addons2?.map(e=>addons[Number(e)].value)
    var pkg1 = {packageName:data.package1,addons:addons1,price:totalPrice1}
    var pkg2 = {packageName:data.package2,addons:addons2,price:totalPrice2}
    setValues({...values,packageDetails:family?[pkg1,pkg2]:[pkg1]})
    handleStep();
  }
  return (
  <div className="container-fluid p-4 bg-white border shadow-sm">
    <form onSubmit={handleSubmit(onSubmit)}>
      <div className="row">  
        {/* Package 1 */}
        <div className="col-md-5">
          <div className="py-2 text-dark font-medium">Package  
          {family?<><span>( For {values.employeeDetails[0]?.name} ) </span></>:<></>} 
          *</div>
          <select name={"package1"} className="form-select" ref={register({required:true})}>
              <option value="">- Select Package -</option>
              <option value="Comprehensive Active Professional Health Checkup">Comprehensive Active Professional Health Checkup</option>
              <option value="Comprehensive young Indian Health Checkup">Comprehensive young Indian Health Checkup</option>
              <option value="Young Indian Health Checkup">Young Indian Health Checkup</option>
              <option value="Active Professional Health Checkup">Active Professional Health Checkup</option>
          </select>
          {errors.package1?.type==="required" && <small className="text-danger">Package is required</small>}
        </div> 
        <div className="col-md-12">
          <div className="py-2 text-dark font-medium">Comprehensive Active Professional Health Checkup</div>
          <div className="text-secondary -my-2">Ideal for individuals aged 41 to 60 years</div>
          <div className="flex-row md:flex my-2">
            <div className="flex">
              <div className="p-2"> 
                <div>PS</div>
                <div>RBS</div>
                <div>FBS</div>
                <div>ESR</div>
                <div>HbA1c</div>
                <div>RA Factor</div>
                <div>Lipid Profile (7)</div>
              </div>
              <div className="p-2">
                <div>Kidney Function Test (7)</div>
                <div>TSH</div>
                <div>T3</div>
                <div>T4</div>
                <div>Urine Complete Analysis (21)</div>
                <div>Iron Profile (4)</div>
                <div>Vitamin D</div>
              </div>
            </div>
            <div className="ml-auto text-right md:text-left px-4 font-medium">
              <div> <s>Rs. 324</s> </div>
              <div>FREE</div>
            </div>
          </div>
          <div className="py-2 text-dark font-medium">Add-on Tests</div>
          <div className="flex"> 
            <div className="flex-row md:flex">
              {addons.map((el,key)=>(
                <div key={key} className="flex items-center mr-1">
                    <input type="checkbox" defaultValue={key} onChange={handleChange1} name="addons1" ref={register} />
                    <span className="text-sm font-medium mx-2">{el.value}</span>
                </div>
              ))} 
            </div>
            <div className="ml-auto px-4 font-medium">
              <div>Rs. {totalPrice1}</div> 
            </div> 
          </div>
        </div>
        
        {/* Package 2 */}
        {family?<>
          <div className="col-md-5">
            <div className="py-2 text-dark font-medium">Package  
            {family?<><span>( For {values.employeeDetails[1]?.name} ) </span></>:<></>} 
            *</div>
            <select name={"package2"} className="form-select" ref={register({required:true})}>
                <option value="">- Select Package -</option>
                <option value="Comprehensive Active Professional Health Checkup">Comprehensive Active Professional Health Checkup</option>
                <option value="Comprehensive young Indian Health Checkup">Comprehensive young Indian Health Checkup</option>
                <option value="Young Indian Health Checkup">Young Indian Health Checkup</option>
                <option value="Active Professional Health Checkup">Active Professional Health Checkup</option>
            </select>
            {errors.package2?.type==="required" && <small className="text-danger">Package is required</small>}
          </div> 
          <div className="col-md-12">
            <div className="py-2 text-dark font-medium">Comprehensive Active Professional Health Checkup</div>
            <div className="text-secondary -my-2">Ideal for individuals aged 41 to 60 years</div>
            <div className="flex-row md:flex my-2">
              <div className="flex">
                <div className="p-2"> 
                  <div>PS</div>
                  <div>RBS</div>
                  <div>FBS</div>
                  <div>ESR</div>
                  <div>HbA1c</div>
                  <div>RA Factor</div>
                  <div>Lipid Profile (7)</div>
                </div>
                <div className="p-2">
                  <div>Kidney Function Test (7)</div>
                  <div>TSH</div>
                  <div>T3</div>
                  <div>T4</div>
                  <div>Urine Complete Analysis (21)</div>
                  <div>Iron Profile (4)</div>
                  <div>Vitamin D</div>
                </div>
              </div>
              <div className="ml-auto text-right md:text-left px-4 font-medium">
                <div> <s>Rs. 324</s> </div>
                <div>FREE</div>
              </div>
            </div>
            <div className="py-2 text-dark font-medium">Add-on Tests</div>
            <div className="flex"> 
              <div className="flex-row md:flex">
                {addons.map((el,key)=>(
                  <div key={key} className="flex items-center mr-1">
                      <input type="checkbox" defaultValue={key} onChange={handleChange2} name="addons2" ref={register} />
                      <span className="text-sm font-medium mx-2">{el.value}</span>
                  </div>
                ))} 
              </div>
              <div className="ml-auto px-4 font-medium">
                <div>Rs. {totalPrice2}</div> 
              </div> 
            </div>
          </div> 
        </>:<></>}


        <div className="col-md-12">
          <button type="submit" className="cursor-pointer p-2 px-3 bg-success text-white text-center w-1/2 md:w-1/6 mt-3">Continue</button>
        </div>
      </div>
    </form>

  </div>
  )
        
}
